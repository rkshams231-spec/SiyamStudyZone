package com.siyam.studyzone.ui.focus

import android.app.Application
import android.content.Context
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.siyam.studyzone.StudyApp
import com.siyam.studyzone.logic.formatClock
import com.siyam.studyzone.logic.formatHM
import com.siyam.studyzone.logic.todayFlow
import com.siyam.studyzone.timer.*
import com.siyam.studyzone.ui.theme.Brand
import com.siyam.studyzone.ui.theme.GlassCard
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*

@OptIn(ExperimentalCoroutinesApi::class)
class FocusViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = (app as StudyApp).db.studyDao()
    val todaySec: StateFlow<Long> = todayFlow().flatMapLatest { d -> dao.totalBetween(d, d) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)
}

@Composable
fun FocusScreen(vm: FocusViewModel = viewModel()) {
    val ctx = LocalContext.current
    val prefs = (ctx.applicationContext as StudyApp).prefs
    val s by TimerController.state.collectAsStateWithLifecycle()
    val today by vm.todaySec.collectAsStateWithLifecycle()
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var showStop by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        while (true) { now = System.currentTimeMillis(); TimerController.checkFinished(); delay(250) }
    }

    val elapsed = s.elapsedMs(now)
    val shownSec = if (s.mode == Mode.STOPWATCH) elapsed / 1000 else s.remainingSec(now)
    val progress = when {
        s.mode == Mode.STOPWATCH -> ((elapsed / 1000) % 3600) / 3600f
        s.totalSec > 0 -> (elapsed / 1000f / s.totalSec).coerceIn(0f, 1f)
        else -> 0f
    }
    val animated by animateFloatAsState(progress, tween(300), label = "progress")
    val canSwitch = s.status == Status.IDLE

    fun startOrResume() { TimerController.start(); TimerService.ensureRunning(ctx) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("TODAY'S STUDY", color = Brand.Muted, fontSize = 12.sp, letterSpacing = 2.sp)
                Text(formatHM(today), fontSize = 40.sp, fontWeight = FontWeight.Bold, color = Brand.Cyan)
            }
            IconButton(onClick = { showSettings = true }) { Icon(Icons.Rounded.Settings, "Timer settings") }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(Mode.POMODORO to "Pomodoro", Mode.TIMER to "Timer", Mode.STOPWATCH to "Stopwatch").forEach { (m, label) ->
                FilterChip(selected = s.mode == m, enabled = canSwitch || s.mode == m, onClick = { TimerController.selectMode(m) }, label = { Text(label) })
            }
        }

        GlassCard {
            Text(
                when {
                    s.mode == Mode.STOPWATCH -> "Stopwatch"
                    s.mode == Mode.TIMER -> "Countdown Timer"
                    s.phase == Phase.FOCUS -> "Focus · Session ${s.pomodoroCount % prefs.longEvery + 1} of ${prefs.longEvery}"
                    s.phase == Phase.SHORT_BREAK -> "Short Break"
                    else -> "Long Break"
                }, color = Brand.Muted, modifier = Modifier.align(Alignment.CenterHorizontally)
            )
            Spacer(Modifier.height(16.dp))
            Box(Modifier.fillMaxWidth(0.75f).aspectRatio(1f).align(Alignment.CenterHorizontally), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(
                    progress = { 1f }, modifier = Modifier.fillMaxSize(), strokeWidth = 10.dp,
                    color = Brand.Border, strokeCap = StrokeCap.Round
                )
                CircularProgressIndicator(
                    progress = { animated }, modifier = Modifier.fillMaxSize(), strokeWidth = 10.dp,
                    color = if (s.phase == Phase.FOCUS) Brand.Purple else Brand.Green,
                    trackColor = androidx.compose.ui.graphics.Color.Transparent, strokeCap = StrokeCap.Round
                )
                Text(formatClock(shownSec), fontSize = 48.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(20.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterHorizontally)) {
                when (s.status) {
                    Status.IDLE -> Button(onClick = { startOrResume() }) { Text("START") }
                    Status.RUNNING -> Button(onClick = { TimerController.pause() }) { Text("PAUSE") }
                    Status.PAUSED -> Button(onClick = { startOrResume() }) { Text("RESUME") }
                }
                if (s.mode == Mode.STOPWATCH) {
                    OutlinedButton(enabled = s.status != Status.IDLE, onClick = { TimerController.pause(); showStop = true }) { Text("STOP") }
                } else {
                    OutlinedButton(enabled = s.status != Status.IDLE, onClick = { TimerController.reset() }) { Text("RESET") }
                }
            }
            if (s.mode == Mode.POMODORO && s.phase != Phase.FOCUS && s.status == Status.IDLE) {
                TextButton(onClick = { TimerController.skipBreak() }, modifier = Modifier.align(Alignment.CenterHorizontally)) { Text("Skip break") }
            }
            if (s.mode == Mode.TIMER && s.status == Status.IDLE) {
                Spacer(Modifier.height(8.dp))
                Row(Modifier.align(Alignment.CenterHorizontally), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(30, 60, 120, 180).forEach { m ->
                        FilterChip(selected = s.totalSec / 60 == m, onClick = { prefs.timerMin = m; TimerController.refreshDurations() },
                            label = { Text(if (m < 60) "${m}m" else "${m / 60}h") })
                    }
                }
            }
        }
        Text("Only completed focus time counts. Breaks and reset sessions are never added.", color = Brand.Muted, fontSize = 12.sp)
    }

    if (showStop) {
        val sec = TimerController.state.value.elapsedMs(System.currentTimeMillis()) / 1000
        AlertDialog(
            onDismissRequest = { showStop = false },
            title = { Text("Save this session?") },
            text = { Text("${formatClock(sec)} of study time will be added to today.") },
            confirmButton = { TextButton(onClick = { TimerController.saveStopwatch(); showStop = false }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { TimerController.reset(); showStop = false }) { Text("Discard") } }
        )
    }
    if (showSettings) TimerSettingsDialog(ctx, onClose = { showSettings = false })
}

@Composable
private fun TimerSettingsDialog(ctx: Context, onClose: () -> Unit) {
    val p = (ctx.applicationContext as StudyApp).prefs
    var focus by remember { mutableStateOf(p.focusMin.toString()) }
    var short by remember { mutableStateOf(p.shortMin.toString()) }
    var long by remember { mutableStateOf(p.longMin.toString()) }
    var every by remember { mutableStateOf(p.longEvery.toString()) }
    var timer by remember { mutableStateOf(p.timerMin.toString()) }
    fun ok(v: String) = v.toIntOrNull()?.let { it in 1..600 } == true
    val valid = listOf(focus, short, long, every, timer).all(::ok)

    @Composable fun field(label: String, v: String, set: (String) -> Unit) = OutlinedTextField(
        value = v, onValueChange = { set(it.filter(Char::isDigit).take(3)) }, label = { Text(label) }, singleLine = true,
        isError = !ok(v), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth()
    )
    AlertDialog(
        onDismissRequest = onClose, title = { Text("Timer settings") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                field("Focus (min)", focus) { focus = it }; field("Short break (min)", short) { short = it }
                field("Long break (min)", long) { long = it }; field("Sessions before long break", every) { every = it }
                field("Countdown timer (min)", timer) { timer = it }
            }
        },
        confirmButton = {
            TextButton(enabled = valid, onClick = {
                p.focusMin = focus.toInt(); p.shortMin = short.toInt(); p.longMin = long.toInt()
                p.longEvery = every.toInt(); p.timerMin = timer.toInt()
                TimerController.refreshDurations(); onClose()
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } }
    )
}
