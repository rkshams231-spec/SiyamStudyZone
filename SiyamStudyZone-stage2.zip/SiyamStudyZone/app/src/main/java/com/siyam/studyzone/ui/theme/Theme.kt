package com.siyam.studyzone.ui.theme

import androidx.compose.foundation.border
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

object Brand {
    val Navy = Color(0xFF0B1020); val Card = Color(0xFF141B34); val CardTop = Color(0xFF1D2650)
    val Purple = Color(0xFF7C6CFF); val Cyan = Color(0xFF22D3EE); val Green = Color(0xFF34D399)
    val Warn = Color(0xFFFB923C); val Border = Color(0x22FFFFFF); val Muted = Color(0xFF9AA4C7)
    val Gradient = Brush.horizontalGradient(listOf(Purple, Cyan))
}

private val Scheme = darkColorScheme(
    primary = Brand.Purple, secondary = Brand.Cyan, tertiary = Brand.Green,
    background = Brand.Navy, surface = Brand.Card, onBackground = Color(0xFFF1F4FF), onSurface = Color(0xFFF1F4FF),
    surfaceVariant = Color(0xFF1D2650), onSurfaceVariant = Brand.Muted, error = Brand.Warn
)

@Composable
fun StudyTheme(content: @Composable () -> Unit) = MaterialTheme(colorScheme = Scheme, content = content)

/** Standard rounded card used across all screens. */
@Composable
fun GlassCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(24.dp)
    Column(
        modifier.fillMaxWidth().clip(shape)
            .background(Brush.verticalGradient(listOf(Brand.CardTop, Brand.Card)))
            .border(1.dp, Brand.Border, shape).padding(20.dp),
        content = content
    )
}
