package com.siyam.studyzone.ui

import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Dashboard
import androidx.compose.material.icons.rounded.TaskAlt
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.siyam.studyzone.StudyApp
import com.siyam.studyzone.timer.TimerController
import com.siyam.studyzone.timer.TimerService
import com.siyam.studyzone.ui.focus.FocusScreen
import com.siyam.studyzone.ui.theme.Brand

@Composable
fun AppRoot() {
    val ctx = LocalContext.current
    val prefs = (ctx.applicationContext as StudyApp).prefs
    var tab by rememberSaveable { mutableIntStateOf(prefs.lastTab) }
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(Unit) {
        TimerService.ensureRunning(ctx)
        TimerController.events.collect { snack.showSnackbar(it) }
    }
    val items = listOf("Dashboard" to Icons.Rounded.Dashboard, "Focus" to Icons.Rounded.Timer, "Daily Goals" to Icons.Rounded.TaskAlt)
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snack) },
        bottomBar = {
            NavigationBar(containerColor = Brand.Card) {
                items.forEachIndexed { i, (label, icon) ->
                    NavigationBarItem(
                        selected = tab == i, onClick = { tab = i; prefs.lastTab = i },
                        icon = { Icon(icon, label) }, label = { Text(label) },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = Brand.Purple.copy(alpha = 0.30f),
                            selectedIconColor = Brand.Cyan, selectedTextColor = Brand.Cyan
                        )
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            Crossfade(tab, label = "tab") {
                when (it) {
                    1 -> FocusScreen()
                    else -> Box(Modifier.fillMaxSize(), Alignment.Center) { Text("${items[it].first} — built in the next stage") }
                }
            }
        }
    }
}
