package com.siyam.studyzone.timer

import android.content.Context
import com.siyam.studyzone.StudyApp
import com.siyam.studyzone.data.StudySession
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDate

enum class Mode { POMODORO, TIMER, STOPWATCH }
enum class Phase { FOCUS, SHORT_BREAK, LONG_BREAK }
enum class Status { IDLE, RUNNING, PAUSED }

/** Timestamp-based timer state: survives app/process death because time is derived from the wall clock. */
data class TimerState(
    val mode: Mode = Mode.POMODORO,
    val phase: Phase = Phase.FOCUS,
    val status: Status = Status.IDLE,
    val totalSec: Int = 1500,
    val startedAtMs: Long = 0L,
    val accumulatedMs: Long = 0L,
    val pomodoroCount: Int = 0
) {
    fun elapsedMs(now: Long) = accumulatedMs + if (status == Status.RUNNING) (now - startedAtMs).coerceAtLeast(0L) else 0L
    fun remainingMs(now: Long) = (totalSec * 1000L - elapsedMs(now)).coerceAtLeast(0L)
    fun remainingSec(now: Long) = (remainingMs(now) + 999) / 1000
}

object TimerController {
    private lateinit var app: StudyApp
    private lateinit var sp: android.content.SharedPreferences
    private val _state = MutableStateFlow(TimerState())
    val state: StateFlow<TimerState> = _state
    private val _events = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val events: SharedFlow<String> = _events
    private fun now() = System.currentTimeMillis()

    fun init(a: StudyApp) {
        app = a
        sp = a.getSharedPreferences("timer_state", Context.MODE_PRIVATE)
        _state.value = load()
        refreshDurations()
        checkFinished()   // completes sessions that ended while the app was closed
    }

    private fun idleTotal(m: Mode, p: Phase): Int = when (m) {
        Mode.POMODORO -> 60 * when (p) { Phase.FOCUS -> app.prefs.focusMin; Phase.SHORT_BREAK -> app.prefs.shortMin; Phase.LONG_BREAK -> app.prefs.longMin }
        Mode.TIMER -> 60 * app.prefs.timerMin
        Mode.STOPWATCH -> 0
    }

    @Synchronized private fun set(s: TimerState) {
        _state.value = s
        sp.edit().putString("mode", s.mode.name).putString("phase", s.phase.name).putString("status", s.status.name)
            .putInt("total", s.totalSec).putLong("start", s.startedAtMs).putLong("acc", s.accumulatedMs)
            .putInt("count", s.pomodoroCount).apply()
    }

    private fun load(): TimerState = try {
        TimerState(
            Mode.valueOf(sp.getString("mode", "POMODORO")!!), Phase.valueOf(sp.getString("phase", "FOCUS")!!),
            Status.valueOf(sp.getString("status", "IDLE")!!), sp.getInt("total", 1500),
            sp.getLong("start", 0L), sp.getLong("acc", 0L), sp.getInt("count", 0)
        )
    } catch (e: Exception) { TimerState() }

    @Synchronized fun refreshDurations() {
        val s = _state.value
        if (s.status == Status.IDLE) set(s.copy(totalSec = idleTotal(s.mode, s.phase)))
    }

    @Synchronized fun selectMode(m: Mode) {
        val s = _state.value
        if (s.status == Status.IDLE) set(s.copy(mode = m, phase = Phase.FOCUS, accumulatedMs = 0, totalSec = idleTotal(m, Phase.FOCUS)))
    }

    @Synchronized fun start() {
        val s = _state.value
        when (s.status) {
            Status.IDLE -> set(s.copy(status = Status.RUNNING, startedAtMs = now(), accumulatedMs = 0))
            Status.PAUSED -> set(s.copy(status = Status.RUNNING, startedAtMs = now()))
            Status.RUNNING -> {}
        }
    }

    @Synchronized fun pause() {
        val s = _state.value
        if (s.status == Status.RUNNING) set(s.copy(status = Status.PAUSED, accumulatedMs = s.elapsedMs(now())))
    }

    /** Discards the current run. Nothing is counted as study time. */
    @Synchronized fun reset() {
        val s = _state.value
        set(s.copy(status = Status.IDLE, accumulatedMs = 0, totalSec = idleTotal(s.mode, s.phase)))
    }

    @Synchronized fun skipBreak() {
        val s = _state.value
        if (s.status == Status.IDLE && s.phase != Phase.FOCUS) set(s.copy(phase = Phase.FOCUS, totalSec = idleTotal(s.mode, Phase.FOCUS)))
    }

    /** Stopwatch: user confirmed saving the elapsed time as study time. */
    @Synchronized fun saveStopwatch() {
        val s = _state.value
        if (s.mode != Mode.STOPWATCH) return
        val sec = (s.elapsedMs(now()) / 1000).toInt()
        if (sec > 0) {
            record(Mode.STOPWATCH, sec)
            _events.tryEmit("Saved ${sec / 60} min ${sec % 60}s to today's study time.")
        }
        reset()
    }

    @Synchronized fun checkFinished() {
        val s = _state.value
        if (s.status == Status.RUNNING && s.mode != Mode.STOPWATCH && s.elapsedMs(now()) >= s.totalSec * 1000L) complete(s)
    }

    private fun complete(s: TimerState) {
        if (s.mode == Mode.POMODORO && s.phase != Phase.FOCUS) {
            finish(s.copy(status = Status.IDLE, accumulatedMs = 0, phase = Phase.FOCUS), "Break finished", "Ready for your next focus session.")
            return
        }
        record(s.mode, s.totalSec)
        val mins = s.totalSec / 60
        if (s.mode == Mode.POMODORO) {
            val count = s.pomodoroCount + 1
            val next = if (count % app.prefs.longEvery == 0) Phase.LONG_BREAK else Phase.SHORT_BREAK
            finish(s.copy(status = Status.IDLE, accumulatedMs = 0, phase = next, pomodoroCount = count),
                "Pomodoro #$count completed ✓", "$mins minutes added to today's study time.")
        } else {
            finish(s.copy(status = Status.IDLE, accumulatedMs = 0), "Timer complete 🎉", "$mins minutes added to today's study time.")
        }
    }

    private fun finish(n: TimerState, title: String, text: String) {
        set(n.copy(totalSec = idleTotal(n.mode, n.phase)))
        _events.tryEmit("$title\n$text")
        Notifier.alert(app, title, text)
    }

    private fun record(mode: Mode, sec: Int) {
        val s = StudySession(dayEpoch = LocalDate.now().toEpochDay(), startedAtMs = now() - sec * 1000L, durationSec = sec, mode = mode.name)
        app.scope.launch { app.db.studyDao().insert(s) }
    }
}
