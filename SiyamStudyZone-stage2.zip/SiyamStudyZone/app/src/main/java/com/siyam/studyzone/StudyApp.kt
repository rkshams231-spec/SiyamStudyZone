package com.siyam.studyzone

import android.app.Application
import androidx.room.Room
import com.siyam.studyzone.data.AppDatabase
import com.siyam.studyzone.data.Prefs
import com.siyam.studyzone.timer.Notifier
import com.siyam.studyzone.timer.TimerController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

class StudyApp : Application() {
    val db by lazy { Room.databaseBuilder(this, AppDatabase::class.java, "studyzone.db").build() }
    val prefs by lazy { Prefs(this) }
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        Notifier.init(this)
        TimerController.init(this)
    }
}
