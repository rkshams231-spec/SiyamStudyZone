package com.siyam.studyzone.data

import android.content.Context

/** Small settings store (SharedPreferences). Survives restarts. */
class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("szone", Context.MODE_PRIVATE)
    private fun int(k: String, d: Int) = sp.getInt(k, d)
    private fun put(k: String, v: Int) = sp.edit().putInt(k, v).apply()

    var userName: String
        get() = sp.getString("name", "Siyam") ?: "Siyam"
        set(v) = sp.edit().putString("name", v).apply()
    var examEpochDay: Long
        get() = sp.getLong("exam", -1L)
        set(v) = sp.edit().putLong("exam", v).apply()
    var targetHours: Int get() = int("target", 10); set(v) = put("target", v)
    var focusMin: Int get() = int("focus", 25); set(v) = put("focus", v)
    var shortMin: Int get() = int("short", 5); set(v) = put("short", v)
    var longMin: Int get() = int("long", 15); set(v) = put("long", v)
    var longEvery: Int get() = int("longEvery", 4); set(v) = put("longEvery", v)
    var timerMin: Int get() = int("timer", 60); set(v) = put("timer", v)
    var lastTab: Int get() = int("tab", 0); set(v) = put("tab", v)
}
