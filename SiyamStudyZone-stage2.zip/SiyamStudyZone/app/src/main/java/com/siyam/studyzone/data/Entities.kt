package com.siyam.studyzone.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

enum class SessionMode { POMODORO, TIMER, STOPWATCH }

/** One completed/confirmed study session. dayEpoch = LocalDate.toEpochDay() in device time zone. */
@Entity(tableName = "study_sessions", indices = [Index("dayEpoch")])
data class StudySession(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dayEpoch: Long,
    val startedAtMs: Long,
    val durationSec: Int,
    val mode: String
)

/** Per-day, per-goal completion. History is kept forever; a new day simply has no rows yet. */
@Entity(tableName = "goal_checks", primaryKeys = ["dayEpoch", "goalId"])
data class GoalCheck(val dayEpoch: Long, val goalId: Int, val done: Boolean)

data class DayTotal(val dayEpoch: Long, val totalSec: Long)
data class DayGoalCount(val dayEpoch: Long, val doneCount: Int)
