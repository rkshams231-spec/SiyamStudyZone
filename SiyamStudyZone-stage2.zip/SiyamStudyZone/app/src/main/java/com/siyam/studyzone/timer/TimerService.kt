package com.siyam.studyzone.timer

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*

/** Keeps the process alive while a timer runs and finishes sessions even with the screen locked. */
class TimerService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val n = Notifier.running(this, TimerController.state.value)
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
        job?.cancel()
        job = scope.launch {
            while (isActive) {
                TimerController.checkFinished()
                if (TimerController.state.value.status != Status.RUNNING) break
                delay(1000)
            }
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() { scope.cancel() }

    companion object {
        fun ensureRunning(ctx: Context) {
            if (TimerController.state.value.status != Status.RUNNING) return
            try { ContextCompat.startForegroundService(ctx, Intent(ctx, TimerService::class.java)) } catch (_: Exception) {}
        }
    }
}
