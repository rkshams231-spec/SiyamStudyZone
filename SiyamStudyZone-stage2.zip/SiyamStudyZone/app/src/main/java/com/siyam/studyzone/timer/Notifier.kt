package com.siyam.studyzone.timer

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.siyam.studyzone.MainActivity

object Notifier {
    private const val CH_RUN = "running"
    private const val CH_ALERT = "alerts"

    fun init(ctx: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CH_RUN, "Active timer", NotificationManager.IMPORTANCE_LOW))
            nm.createNotificationChannel(NotificationChannel(CH_ALERT, "Timer alerts", NotificationManager.IMPORTANCE_HIGH))
        }
    }

    private fun openApp(ctx: Context) = PendingIntent.getActivity(
        ctx, 0, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    fun running(ctx: Context, s: TimerState): Notification {
        val now = System.currentTimeMillis()
        val title = when {
            s.mode == Mode.STOPWATCH -> "Stopwatch running"
            s.mode == Mode.POMODORO && s.phase != Phase.FOCUS -> "Break time"
            else -> "Focus session"
        }
        val b = NotificationCompat.Builder(ctx, CH_RUN)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle(title)
            .setOngoing(true).setOnlyAlertOnce(true).setContentIntent(openApp(ctx)).setUsesChronometer(true)
        if (s.mode == Mode.STOPWATCH) b.setWhen(now - s.elapsedMs(now))
        else b.setWhen(now + s.remainingMs(now)).setChronometerCountDown(true)
        return b.build()
    }

    fun alert(ctx: Context, title: String, text: String) {
        try {
            val nm = NotificationManagerCompat.from(ctx)
            if (!nm.areNotificationsEnabled()) return
            nm.notify(System.currentTimeMillis().toInt(), NotificationCompat.Builder(ctx, CH_ALERT)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle(title).setContentText(text)
                .setAutoCancel(true).setContentIntent(openApp(ctx)).build())
        } catch (_: SecurityException) { /* permission denied: fail quietly */ }
    }
}
