package com.siyam.studyzone.logic

import kotlinx.coroutines.flow.distinctUntilChanged
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.temporal.ChronoUnit
import java.time.temporal.TemporalAdjusters

/** Central, easy-to-edit rules. */
object Rules {
    /** Week start (Bangladesh week begins Saturday). Change to MONDAY etc. if you prefer. */
    val WEEK_START: DayOfWeek = DayOfWeek.SATURDAY
    const val DEFAULT_DAILY_TARGET_HOURS = 10
}

object DateRanges {
    fun week(today: LocalDate): LongRange {
        val start = today.with(TemporalAdjusters.previousOrSame(Rules.WEEK_START))
        return start.toEpochDay()..start.plusDays(6).toEpochDay()
    }
    fun month(ym: YearMonth): LongRange = ym.atDay(1).toEpochDay()..ym.atEndOfMonth().toEpochDay()
}

/** Chart data for a whole month: one entry per calendar day (handles leap years / month lengths). */
fun monthSeries(ym: YearMonth, totals: Map<Long, Long>): List<Pair<Int, Long>> =
    (1..ym.lengthOfMonth()).map { d -> d to (totals[ym.atDay(d).toEpochDay()] ?: 0L) }

/** Streak = consecutive days (ending today, or yesterday if today isn't met yet) reaching the target. */
fun studyStreak(totals: Map<Long, Long>, today: LocalDate, targetSec: Long): Int {
    if (targetSec <= 0) return 0
    fun met(d: Long) = (totals[d] ?: 0L) >= targetSec
    var day = today.toEpochDay()
    if (!met(day)) day -= 1
    var n = 0
    while (met(day)) { n++; day-- }
    return n
}

sealed interface Countdown {
    data class DaysLeft(val days: Long) : Countdown
    data object ExamToday : Countdown
    data object Passed : Countdown
}

fun examCountdown(today: LocalDate, exam: LocalDate): Countdown {
    val d = ChronoUnit.DAYS.between(today, exam)
    return when { d > 0 -> Countdown.DaysLeft(d); d == 0L -> Countdown.ExamToday; else -> Countdown.Passed }
}

fun formatHM(totalSec: Long): String {
    val m = totalSec / 60
    return "${m / 60}h ${m % 60}m"
}

fun greetingFor(hour: Int): String = when (hour) {
    in 5..11 -> "Good Morning"
    in 12..16 -> "Good Afternoon"
    in 17..20 -> "Good Evening"
    else -> "Good Night"
}

data class Goal(val id: Int, val title: String)

val DefaultGoals = listOf(
    Goal(1, "Wake up before 6:00 AM"), Goal(2, "30 min Workout"), Goal(3, "Fajr"),
    Goal(4, "Zuhr"), Goal(5, "Asr"), Goal(6, "Maghrib"), Goal(7, "Isha"),
    Goal(8, "Study 10+ Hours"), Goal(9, "Drink 3–4L Water"),
    Goal(10, "Read 10 Pages of a Psychological Book")
)

fun formatClock(totalSec: Long): String {
    val h = totalSec / 3600; val m = (totalSec % 3600) / 60; val s = totalSec % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
}

/** Emits today's epoch day, re-checking every 30s so the day rolls over at midnight. */
fun todayFlow(): kotlinx.coroutines.flow.Flow<Long> =
    kotlinx.coroutines.flow.flow {
        while (true) { emit(LocalDate.now().toEpochDay()); kotlinx.coroutines.delay(30_000) }
    }.distinctUntilChanged()
