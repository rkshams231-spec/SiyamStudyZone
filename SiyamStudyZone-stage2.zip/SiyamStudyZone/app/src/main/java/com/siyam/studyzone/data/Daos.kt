package com.siyam.studyzone.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface StudyDao {
    @Insert suspend fun insert(session: StudySession): Long

    @Query("SELECT COALESCE(SUM(durationSec),0) FROM study_sessions WHERE dayEpoch BETWEEN :from AND :to")
    fun totalBetween(from: Long, to: Long): Flow<Long>

    @Query("SELECT COALESCE(SUM(durationSec),0) FROM study_sessions")
    fun allTimeTotal(): Flow<Long>

    @Query("SELECT dayEpoch, SUM(durationSec) AS totalSec FROM study_sessions WHERE dayEpoch BETWEEN :from AND :to GROUP BY dayEpoch")
    fun dailyTotals(from: Long, to: Long): Flow<List<DayTotal>>

    @Query("SELECT dayEpoch, SUM(durationSec) AS totalSec FROM study_sessions GROUP BY dayEpoch")
    fun allDailyTotals(): Flow<List<DayTotal>>

    @Query("SELECT MIN(dayEpoch) FROM study_sessions")
    fun firstStudyDay(): Flow<Long?>

    @Query("SELECT * FROM study_sessions ORDER BY startedAtMs")
    suspend fun exportAll(): List<StudySession>

    @Query("DELETE FROM study_sessions") suspend fun clear()
}

@Dao
interface GoalDao {
    @Upsert suspend fun upsert(check: GoalCheck)

    @Query("SELECT * FROM goal_checks WHERE dayEpoch = :day")
    fun forDay(day: Long): Flow<List<GoalCheck>>

    @Query("SELECT dayEpoch, SUM(done) AS doneCount FROM goal_checks WHERE dayEpoch BETWEEN :from AND :to GROUP BY dayEpoch ORDER BY dayEpoch DESC")
    fun counts(from: Long, to: Long): Flow<List<DayGoalCount>>

    @Query("SELECT * FROM goal_checks ORDER BY dayEpoch, goalId")
    suspend fun exportAll(): List<GoalCheck>

    @Query("DELETE FROM goal_checks") suspend fun clear()
}

@Database(entities = [StudySession::class, GoalCheck::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun studyDao(): StudyDao
    abstract fun goalDao(): GoalDao
}
